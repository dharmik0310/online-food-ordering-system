

<div class="container">
  <hr>
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="../index.php" class="nav-link px-2 text-dark">Home</a></li>
      
      <li class="nav-item"><a href="../pages/faq.php" class="nav-link px-2 text-dark">FAQs</a></li>
      <li class="nav-item"><a href="../pages/aboutus.php" class="nav-link px-2 text-dark">About</a></li>
      <li class="nav-item"><a href="../dashboard/" class="nav-link px-2 text-dark">Admin Login</a></li>
    </ul>
    <p class="text-center text-muted">© 2022 FoodsFly, Org</p>
  </footer>
</div>